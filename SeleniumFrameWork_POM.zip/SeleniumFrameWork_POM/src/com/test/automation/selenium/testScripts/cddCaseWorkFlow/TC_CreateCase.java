package com.test.automation.selenium.testScripts.cddCaseWorkFlow;

import org.openqa.selenium.WebDriver;

import com.test.automation.selenium.businesscomponents.*;
import com.test.automation.selenium.framework.Browser;

public class TC_CreateCase {
	
public static WebDriver driver=Browser.driver;
	
	public void ExecuteTest(String BrowserType, String strProgramDetails, String strTestEnvDetails) throws Exception 
	{
			
		try{
			
			CaseWorkFlow_CreateCase.run(4);
			Thread.sleep(2000);
			
			}catch(Exception ex){
			
		}
		
		//Logout.run(4);
				
	 }

}
