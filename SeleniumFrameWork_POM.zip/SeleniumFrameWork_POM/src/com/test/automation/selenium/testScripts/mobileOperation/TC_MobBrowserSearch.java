package com.test.automation.selenium.testScripts.mobileOperation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.test.automation.selenium.businesscomponents.*;
import com.test.automation.selenium.framework.Browser;
import com.test.automation.selenium.framework.ExcelUtil;

public class TC_MobBrowserSearch {
	
	public static WebDriver driver=Browser.driver;
	public String filename = "C:\\Selenium\\POC\\SeleniumFrameWork_POM\\testdata\\MobileOperation.xlsx";
	public String sheetname = "MobileOperation_SearchTest";
	public static String strText = null;
	
	public void ExecuteTest(String BrowserType, String strProgramDetails, String strTestEnvDetails) throws Exception 
	{
			
		try{
			
			
			MobOperation_SearchTest.run(BrowserType,4);
			Thread.sleep(2000);
			ClickText readexcel = new ClickText();
	        strText = readexcel.getTextValue(filename,sheetname,3);
	        String[] splited = strText.split("\\s+");
	        String searchtext = splited[0];
	        ExcelUtil.storeCellData(sheetname, "SearchValue",0,3);
	        ExcelUtil.storeCellData(sheetname, "xpath:://*[text()='"+searchtext+"']",1,3);
	        ExcelUtil.storeCellData(sheetname, "clickon",5,3);
	        //System.out.println("//*[text()='"+splited[0]+"']");//*[text()='Perfecto']
	        MobOperation_ClickText.run(BrowserType,6);
	        //Wait for 15 Sec
			Thread.sleep(15000);
			driver.quit();
			}catch(Exception ex){
			
		}
		
		//Logout.run(4);
				
	 }

}
