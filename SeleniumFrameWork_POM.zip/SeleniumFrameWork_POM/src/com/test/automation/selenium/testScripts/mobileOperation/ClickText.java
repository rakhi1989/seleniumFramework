package com.test.automation.selenium.testScripts.mobileOperation;

//import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

//import org.apache.poi.xssf.usermodel.XSSFCell;           
//import org.apache.poi.xssf.usermodel.XSSFRow;           
//import org.apache.poi.xssf.usermodel.XSSFSheet;   
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import com.test.automation.selenium.framework.Browser;
//import org.apache.poi.hssf.usermodel.HSSFCell;           
//import org.apache.poi.hssf.usermodel.HSSFRow;           
//import org.apache.poi.hssf.usermodel.HSSFSheet;   
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;


public class ClickText {
	
	/*private static XSSFWorkbook xlsxExcelWBook;                
	private static XSSFSheet xlsxExcelWSheet;
	private static XSSFRow xlsxRow;
	private static XSSFCell xlsxCell;
	private static HSSFWorkbook xlsExcelWBook;                
	private static HSSFSheet xlsExcelWSheet;
	private static HSSFRow xlsRow;
	private static HSSFCell xlsCell;*/ 
	private static Workbook excelWBook = null;
	private static Sheet excelWSheet = null;
	private static Row row = null;
	private static Cell cell0 = null;
	private static Cell cell1 = null;
	
	         
	public  String getTextValue(String filename, String sheetname , int rownum) throws Exception

	{
                //String fileName = System.getProperty("user.dir") + File.separatorChar+"Driver.xlsx";
                //ArrayList<String> tokenList = new ArrayList<String>();
                //HashMap<String,String> hm=new HashMap<String,String>();  
                FileInputStream ExcelFile = null;
                String googletext = null;
                ExcelFile = new FileInputStream(filename);
                String fileExtension = filename.substring(filename.indexOf("."));
                
                if(fileExtension.equals(".xls"))
                {
                                excelWBook = new HSSFWorkbook(ExcelFile);
                                
                }
                
                else if(fileExtension.equals(".xlsx"))
                {
                                excelWBook = new XSSFWorkbook(ExcelFile);
                }
                                                                   
                excelWSheet = excelWBook.getSheet(sheetname);
                int rowCount = excelWSheet.getLastRowNum();
                                                
                //for(int i=1; i<rowCount; i++){
                                
                                row = excelWSheet.getRow(rownum);
                                cell1 = row.getCell(1);
                                googletext = cell1.getStringCellValue();
                                System.out.println(googletext);
                //}
                return (googletext);

}


}
