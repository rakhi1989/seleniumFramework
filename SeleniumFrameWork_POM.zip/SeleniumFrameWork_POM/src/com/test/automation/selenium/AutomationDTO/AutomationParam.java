package com.test.automation.selenium.AutomationDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutomationParam {
	
	public String environment;
	public String url;
	public String browserType;
	public String testDataFolder;
	public String testResultFolder;
	public String browserDriverFolder;
	public String projectName;
	public String getBrowserDriverFolder() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getBrowserType() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getEnvironment() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getProjectName() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getTestResultFolder() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getUrl() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getTestDataFolder() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
