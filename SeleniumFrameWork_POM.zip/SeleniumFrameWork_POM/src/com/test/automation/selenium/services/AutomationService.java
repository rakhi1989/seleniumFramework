package com.test.automation.selenium.services;

import java.util.List;

public interface AutomationService {
	public List<String> getStatus();
}
