package com.test.automation.selenium.framework;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {
    private Properties properties;
    private final String propertyFilePath= "C:\\Selenium\\POC\\SeleniumFrameWork_POM\\Configuration.properties";

    
    public ConfigFileReader(){
           BufferedReader reader;
           try {
                  reader = new BufferedReader(new FileReader(propertyFilePath));
                  properties = new Properties();
                  try {
                        properties.load(reader);
                        reader.close();
                  } catch (IOException e) {
                        e.printStackTrace();
                  }
           } catch (FileNotFoundException e) {
                  e.printStackTrace();
                  throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
           }             
    }
    
    
    public String getpfuser(){
        String driverPath = properties.getProperty("pfuser");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("User details not specified in the Configuration.properties file.");             
 }
    public String getpfuser1(){
        String driverPath = properties.getProperty("pfuser1");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("User details not specified in the Configuration.properties file.");             
 }
    
    public String getpfpassword(){
        String driverPath = properties.getProperty("pfpassword");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("Password not specified in the Configuration.properties file.");             
 }
    public String getpfplatform(){
        String driverPath = properties.getProperty("pfplatform");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("Platform not specified in the Configuration.properties file.");             
 }
    public String getpfplatformversion(){
        String driverPath = properties.getProperty("pfplatformversion");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("platformversion not specified in the Configuration.properties file.");             
 }
    public String getpfbrowser(){
        String driverPath = properties.getProperty("pfbrowser");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("Pfbrowser host not specified in the Configuration.properties file.");             
 }
        public String getproxyhost(){
        String driverPath = properties.getProperty("proxyhost");
        if(driverPath!= null) return driverPath;
        else throw new RuntimeException("proxyhost not specified in the Configuration.properties file.");             
 }
        public String getpfbrowserversion(){
            String driverPath = properties.getProperty("pfbrowserversion");
            if(driverPath!= null) return driverPath;
            else throw new RuntimeException("Browser version not specified in the Configuration.properties file.");             
     }
        public String getpfresolution(){
            String driverPath = properties.getProperty("pfresolution");
            if(driverPath!= null) return driverPath;
            else throw new RuntimeException("Resolution not specified in the Configuration.properties file.");             
     }
            public String getpflocation(){
                String driverPath = properties.getProperty("pflocation");
                if(driverPath!= null) return driverPath;
                else throw new RuntimeException("Pflocation  not specified in the Configuration.properties file.");             
         }
            public String pfdevice(){
                String driverPath = properties.getProperty("pfdevice");
                if(driverPath!= null) return driverPath;
                else throw new RuntimeException("Device details not specified in the Configuration.properties file.");             
         }
            
    
    
    public String getRemotePath(){
           String driverPath = properties.getProperty("remotehost");
           if(driverPath!= null) return driverPath;
           else throw new RuntimeException("remote host not specified in the Configuration.properties file.");             
    }
    
    public long getImplicitlyWait() {             
           String implicitlyWait = properties.getProperty("implicitlyWait");
           if(implicitlyWait != null) return Long.parseLong(implicitlyWait);
           else throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file.");             
    }
    
    public String getApplicationUrl() {
           String url = properties.getProperty("url");
           if(url != null) return url;
           else throw new RuntimeException("url not specified in the Configuration.properties file.");
    }

}
